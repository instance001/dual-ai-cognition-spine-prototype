
#!/usr/bin/env python3
import os, json, argparse, requests
from concurrent.futures import ThreadPoolExecutor, as_completed
OPENAI_URL=os.environ.get('OPENAI_URL','https://api.openai.com/v1/chat/completions')
def call_openai(model, system_prompt, user_prompt, api_key, temperature=0.7, top_p=0.9):
    headers={'Authorization': f'Bearer {api_key}', 'Content-Type':'application/json'}
    body={'model':model,'messages':[{'role':'system','content':system_prompt.strip()},{'role':'user','content':user_prompt.strip()}],'temperature':temperature,'top_p':top_p}
    r=requests.post(OPENAI_URL, headers=headers, json=body, timeout=60); r.raise_for_status(); return r.json()['choices'][0]['message']['content'].strip()
def load_text(p): return open(p,'r',encoding='utf-8').read() if p else ''
def main():
    ap=argparse.ArgumentParser(description='Helix Session: Analyst + Synthesist -> Integrator [+ Critic]')
    ap.add_argument('--input','-i',required=True); ap.add_argument('--roleA',default='prompt_templates/analyst.txt'); ap.add_argument('--roleB',default='prompt_templates/synthesist.txt')
    ap.add_argument('--integrator',default='prompt_templates/integrator.txt'); ap.add_argument('--critic',default=None)
    ap.add_argument('-mA',default=os.environ.get('MODEL_A','gpt-4o')); ap.add_argument('-mB',default=os.environ.get('MODEL_B','gpt-4o')); ap.add_argument('-mC',default=os.environ.get('MODEL_C','gpt-4o'))
    ap.add_argument('--tempA',type=float,default=0.5); ap.add_argument('--tempB',type=float,default=0.9); ap.add_argument('--tempC',type=float,default=0.6)
    args=ap.parse_args()
    sysA,sysB,sysI=load_text(args.roleA), load_text(args.roleB), load_text(args.integrator); sysC=load_text(args.critic) if args.critic else None
    keyA=os.environ.get('OPENAI_API_KEY_A') or os.environ.get('OPENAI_API_KEY'); keyB=os.environ.get('OPENAI_API_KEY_B') or keyA; keyC=os.environ.get('OPENAI_API_KEY_C') or keyA
    if not keyA: raise SystemExit('Missing OPENAI_API_KEY or OPENAI_API_KEY_A')
    results={}
    with ThreadPoolExecutor(max_workers=2) as pool:
        futA=pool.submit(call_openai, args.mA, sysA, args.input, keyA, args.tempA, 0.9)
        futB=pool.submit(call_openai, args.mB, sysB, args.input, keyB, args.tempB, 0.95)
        for fut, name in zip(as_completed([futA,futB]), ['A','B']): results[name]=fut.result()
    critic_json=None
    if sysC:
        critic_in=json.dumps({'user_task':args.input,'analyst_json':results.get('A',''),'synthesist_json':results.get('B','')}, ensure_ascii=False)
        critic_out=call_openai(args.mC, sysC, critic_in, keyC, args.tempC, 0.9)
        try: critic_json=json.loads(critic_out)
        except Exception: critic_json=None
        if isinstance(critic_json,dict) and critic_json.get('ok') is False:
            rev=f"Revise based on critic feedback:\n{json.dumps(critic_json, ensure_ascii=False)}\n\nOriginal:\n{results['A']}"
            results['A']=call_openai(args.mA, sysA, rev, keyA, args.tempA, 0.9)
    integrator_in=json.dumps({'user_task':args.input,'analyst_json':results.get('A',''),'synthesist_json':results.get('B',''),'critic':critic_json}, ensure_ascii=False)
    merged=call_openai(args.mC, sysI, integrator_in, keyC, args.tempC, 0.9)
    print('\n=== Analyst (A) ===\n', results.get('A','').strip())
    print('\n=== Synthesist (B) ===\n', results.get('B','').strip())
    if critic_json is not None: print('\n=== Critic (C) ===\n', json.dumps(critic_json, indent=2, ensure_ascii=False))
    print('\n=== Integrated Answer ===\n', merged.strip())
if __name__=='__main__': main()
