# Chatty — Persistent Local Assistant
Run `python main.py` or `python main_embed.py` after installing requirements.
