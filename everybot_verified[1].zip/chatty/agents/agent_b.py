from .agent_common import query

def query_agent_b(host, model, prompt, system, timeout_s):
    return query(host, model, prompt, system, timeout_s)
