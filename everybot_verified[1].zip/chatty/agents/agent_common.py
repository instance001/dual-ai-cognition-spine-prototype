
import requests
def query(host, model, prompt, system='', timeout_s=20):
    try:
        payload={'model':model,'prompt': (system + '\n\n' + prompt) if system else prompt, 'stream': False}
        r=requests.post(f"{host}/api/generate", json=payload, timeout=timeout_s); r.raise_for_status()
        return r.json().get('response','').strip()
    except Exception as e:
        return f"[error:{type(e).__name__}] {e}"
