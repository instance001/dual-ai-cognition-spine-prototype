
import json, os
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils.merge import merge_outputs
from utils.router import classify, choose_agents
from utils.retriever import BM25Index
from utils.embed_retriever import EmbedIndex
from agents.agent_a import query_agent_a
from agents.agent_b import query_agent_b
from agents.agent_c import query_agent_c
CONFIG_PATH='config.json'
def load_config(): return json.load(open(CONFIG_PATH,'r',encoding='utf-8'))
def ensure_mem(p): os.makedirs(os.path.dirname(p), exist_ok=True); open(p,'a').close()
def now_iso(): return datetime.now().isoformat(timespec='seconds')
def save_cap(p,c): open(p,'a',encoding='utf-8').write(json.dumps(c, ensure_ascii=False)+'\n')
def call_agent(name,cfg,prompt):
    host=cfg['host']; model=cfg['model']; timeout_s=cfg.get('timeout_s',20); system=cfg.get('system','')
    if name=='A': return 'A', query_agent_a(host, model, prompt, system, timeout_s)
    if name=='B': return 'B', query_agent_b(host, model, prompt, system, timeout_s)
    if name=='C': return 'C', query_agent_c(host, model, prompt, system, timeout_s)
    if name in ('Chunker','Summarizer'): return name, query_agent_a(host, model, prompt, system, timeout_s)
    return name, f'[error] unknown agent {name}'
def build_retr(cfg, path):
    rtype = cfg['memory'].get('retriever','bm25').lower()
    if rtype=='embed': idx=EmbedIndex(path, cfg['memory'].get('embed_model','all-MiniLM-L6-v2'))
    else: idx=BM25Index(path); rtype='bm25'
    idx.build(); return idx, rtype
def main():
    cfg=load_config(); mem=cfg['memory']['path']; ensure_mem(mem)
    retr, rtype = build_retr(cfg, mem)
    print(f'🧠 Dual-AI Spine (A/B/C) online. Retriever={rtype.upper()}. Type exit to quit.')
    while True:
        user=input('\n🗣️ You: ').strip()
        if user.lower() in ('exit','quit'): break
        labels=classify(user); chosen=choose_agents(labels, cfg['routing'])
        ctx_hits=retr.query(user, top_k=cfg['memory'].get('top_k',5))
        ctx='Relevant memory:\n'+'\n'.join([f"- {h['capsule'].get('input','')[:120]} :: {h['capsule'].get('output','')[:200]}" for h in ctx_hits]) if ctx_hits else ''
        results={}
        with ThreadPoolExecutor(max_workers=len(chosen)) as pool:
            futs=[]
            for name in chosen:
                a_cfg=cfg['agents'][name]
                prompt = f"{ctx}\n\nTask:\n{user}" if (name in ('A','C') and ctx) else user
                futs.append(pool.submit(call_agent, name, a_cfg, prompt))
            for fut in as_completed(futs):
                role,text=fut.result(); results[role]=text
        critic_raw=results.get('C',''); ok=None
        try:
            parsed=json.loads(critic_raw) if critic_raw.strip().startswith('{') else {}
            ok=parsed.get('ok',None)
        except: pass
        merged=merge_outputs(results.get('A',''), results.get('B',''), cfg.get('merge',{}).get('style','dialogic'))
        print('\n🤖 Spine:\n', merged)
        if critic_raw: print('\n[Critic C]:\n', critic_raw)
        cap={'timestamp':now_iso(),'input':user,'output':merged,'agents':results,'tags':labels,'critic_ok':ok,'state':'stored'}
        save_cap(mem, cap); retr.add_capsule(cap)
if __name__=='__main__': main()
