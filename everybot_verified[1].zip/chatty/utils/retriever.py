
import json, math, os, re
WORD_RE = re.compile(r"[A-Za-z0-9_]+")
def _tokenize(t): return [w.lower() for w in WORD_RE.findall(t or "")]
class BM25Index:
    def __init__(self, path:str, k1:float=1.5, b:float=0.75):
        self.path=path; self.k1=k1; self.b=b; self.docs=[]; self.doc_len=[]; self.avgdl=0.0; self.df={}; self.idf={}; self._built=False
    def _iter(self):
        if not os.path.exists(self.path): return
        with open(self.path,"r",encoding="utf-8") as f:
            for line in f:
                line=line.strip()
                if not line: continue
                try: yield json.loads(line)
                except: continue
    def build(self):
        self.docs.clear(); self.doc_len.clear(); self.df.clear()
        for cap in self._iter():
            text = " ".join([cap.get("input",""), cap.get("output",""), " ".join(cap.get("tags",[]))])
            toks=_tokenize(text); self.docs.append({"cap":cap,"tokens":toks}); self.doc_len.append(len(toks))
            for t in set(toks): self.df[t]=self.df.get(t,0)+1
        N=max(1,len(self.docs)); self.avgdl=(sum(self.doc_len)/N) if N else 0.0
        self.idf={t: math.log((N - df + 0.5)/(df + 0.5) + 1.0) for t,df in self.df.items()}; self._built=True
    def add_capsule(self, cap): self._built=False
    def ensure(self): 
        if not self._built: self.build()
    def query(self, q:str, top_k:int=5):
        self.ensure(); qt=_tokenize(q)
        if not qt or not self.docs: return []
        scores=[]
        for i, d in enumerate(self.docs):
            tf={}; 
            for t in d["tokens"]: tf[t]=tf.get(t,0)+1
            dl=self.doc_len[i] or 1; s=0.0
            for t in qt:
                if t not in tf: continue
                idf=self.idf.get(t,0.0); num=tf[t]*(self.k1+1.0); den=tf[t]+self.k1*(1.0 - self.b + self.b*dl/(self.avgdl or 1))
                s += idf * (num/(den or 1))
            scores.append((s,i))
        scores.sort(reverse=True,key=lambda x:x[0])
        return [{"score":s,"capsule":self.docs[i]["cap"]} for s,i in scores[:top_k]]
