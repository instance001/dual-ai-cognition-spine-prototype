
DEFAULT_TAGS = {"summarize":["summarize","tl;dr","condense","brief"],"chunk":["chunk","split","segment","long"],"plan":["plan","steps","spec","constraints","acceptance"],"ideate":["idea","ideas","brainstorm","alternatives","names"],"code":["code","function","class","script","bug"]}
def classify(text:str):
    t=(text or '').lower(); hits=set()
    for tag,keys in DEFAULT_TAGS.items():
        if any(k in t for k in keys): hits.add(tag)
    if len(t.split())>800: hits.add('chunk')
    if not hits: hits.add('plan')
    return list(hits)
def choose_agents(labels,cfg):
    out=[]; seen=set()
    for lb in labels:
        for a in cfg.get(lb,[]):
            if a not in seen: out.append(a); seen.add(a)
    return out
