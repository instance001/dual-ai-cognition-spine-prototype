
import os, json, re
try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
except Exception:
    SentenceTransformer=None; np=None
WORD_RE = re.compile(r"[A-Za-z0-9_]+")
def _tok(s): 
    return [w.lower() for w in WORD_RE.findall(s or "")]
class EmbedIndex:
    def __init__(self, path, model_name='all-MiniLM-L6-v2'):
        self.path=path; self.model_name=model_name; self.model=None; self.docs=[]; self.vecs=None; self._built=False; self._fallback=False
    def _try_model(self):
        if SentenceTransformer is None: self._fallback=True; return
        try: self.model=SentenceTransformer(self.model_name)
        except Exception: self._fallback=True
    def _iter(self):
        if not os.path.exists(self.path): return
        with open(self.path,"r",encoding="utf-8") as f:
            for line in f:
                line=line.strip()
                if not line: continue
                try: yield json.loads(line)
                except: continue
    def build(self):
        self.docs.clear(); texts=[]
        for cap in self._iter():
            t=" ".join([cap.get("input",""), cap.get("output",""), " ".join(cap.get("tags",[]))])
            self.docs.append({"cap":cap,"text":t}); texts.append(t)
        if not self.docs: self._built=True; return
        self._try_model()
        if self._fallback or self.model is None or np is None:
            self._built=True; return
        self.vecs=self.model.encode(texts, normalize_embeddings=True); self._built=True
    def add_capsule(self, cap): self._built=False
    def ensure(self): 
        if not self._built: self.build()
    def query(self, q, top_k=5):
        self.ensure()
        if not self.docs: return []
        if self._fallback or self.model is None or self.vecs is None or np is None:
            qtok=set(_tok(q)); scored=[]
            for i,d in enumerate(self.docs):
                toks=set(_tok(d["text"])); score=len(qtok & toks)/(len(qtok)+1e-6); scored.append((score,i))
            scored.sort(reverse=True,key=lambda x:x[0])
            return [{"score":s,"capsule":self.docs[i]["cap"]} for s,i in scored[:top_k]]
        qv=self.model.encode([q], normalize_embeddings=True)[0]
        sims=(self.vecs @ qv); idxs=sims.argsort()[-top_k:][::-1]
        return [{"score":float(sims[i]), "capsule": self.docs[i]["cap"]} for i in idxs]
