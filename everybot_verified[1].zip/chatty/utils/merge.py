def merge_outputs(a,b,style='dialogic'):
    a=(a or '').strip(); b=(b or '').strip()
    return f"[Analyst A says]\n{a}\n\n[Thinker B replies]\n{b}" if style=='dialogic' else a+"\n\n"+b
