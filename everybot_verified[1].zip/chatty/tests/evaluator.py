
import json, re, sys
def norm(s): 
    import re
    return re.sub(r"\s+", " ", (s or "")).strip().lower()
def check(card, output):
    out = norm(output); score = 1.0; details = []
    for rule in card.get("accept", []):
        if "must_include" in rule:
            ok = all(norm(x) in out for x in rule["must_include"]); details.append(("must_include", ok)); 
            if not ok: score -= 0.25
        if "must_include_any" in rule:
            ok = any(norm(x) in out for x in rule["must_include_any"]); details.append(("must_include_any", ok));
            if not ok: score -= 0.25
        if "forbid" in rule:
            ok = all(norm(x) not in out for x in rule["forbid"]); details.append(("forbid", ok));
            if not ok: score -= 0.25
    return max(0.0, score), details
def main():
    results = [json.loads(line) for line in sys.stdin if line.strip()]
    with open("tests/task_cards.jsonl","r",encoding="utf-8") as f:
        cards = {json.loads(l)["id"]: json.loads(l) for l in f if l.strip()}
    report = []; total=0; passed=0
    for r in results:
        cid = r["id"]; out = r.get("output","");
        card = cards[cid]
        score, details = check(card, out); total += 1; 
        if score >= 0.75: passed += 1
        report.append({"id": cid, "score": score, "details": details})
    print(json.dumps({"passed":passed,"total":total,"pass_rate": (passed/total if total else 0.0), "report": report}, indent=2))
if __name__ == "__main__": main()
