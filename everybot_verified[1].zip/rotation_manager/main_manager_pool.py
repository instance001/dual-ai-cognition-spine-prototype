
import json, os, time
from utils.manager import Manager, WorkUnit
from utils.rotation import Rotation
from utils.metrics import MetricsLogger
from utils.merge import merge_outputs
from utils.router import classify
from utils.retriever import BM25Index
try:
    from utils.embed_retriever import EmbedIndex
except Exception:
    EmbedIndex=None
from agents.agent_a import query_agent_a
from agents.agent_b import query_agent_b
from agents.agent_c import query_agent_c
CONFIG_PATH='config.json'
def load_config(): return json.load(open(CONFIG_PATH,'r',encoding='utf-8'))
def ensure_mem(p): os.makedirs(os.path.dirname(p), exist_ok=True); open(p,'a').close()
def build_retr(cfg, path):
    r=cfg['memory'].get('retriever','bm25').lower()
    if r=='embed' and EmbedIndex is not None: idx=EmbedIndex(path, cfg['memory'].get('embed_model','all-MiniLM-L6-v2'))
    else: idx=BM25Index(path); r='bm25'
    idx.build(); return idx, r
def call_agent_low(name,cfg,prompt):
    host=cfg['host']; model=cfg['model']; timeout_s=cfg.get('timeout_s',20); system=cfg.get('system','')
    if name in ('A','A1','A2','R','Ch','S','T'): return name, query_agent_a(host, model, prompt, system, timeout_s)
    if name in ('B','B1','B2'): return name, query_agent_b(host, model, prompt, system, timeout_s)
    if name=='C': return name, query_agent_c(host, model, prompt, system, timeout_s)
    return name, f'[error] unknown agent {name}'
def make_plan_with_pools(prompt, labels, routing, pools):
    prio={'A':3,'B':2,'C':2,'R':2,'S':1,'Ch':1,'T':2}; seq=[]
    for lb in labels:
        for a in routing.get(lb, []):
            if a.endswith('?'): a=a[:-1]
            if a not in seq: seq.append(a)
    return [WorkUnit(role=a, goal=f'{a} on task', inputs={'prompt':prompt}, priority=prio.get(a,1)) for a in seq]
def main():
    cfg=load_config(); mem=cfg['memory']['path']; ensure_mem(mem)
    retr, rtype = build_retr(cfg, mem)
    pools=cfg.get('pools',{}); rot=Rotation(pools, cfg['agents']); metrics=MetricsLogger(cfg.get('metrics_path','memory/manager_metrics.jsonl'))
    mgr=Manager(cfg['agents'], max_workers=cfg.get('manager',{}).get('max_workers',4), revision_limit=cfg.get('manager',{}).get('revision_limit',1))
    print(f'🎛️ Manager+Rotation online (retriever={rtype.upper()}). Type exit to quit.')
    while True:
        user=input('\n🗣️ You: ').strip()
        if user.lower() in ('exit','quit'): break
        labels=classify(user); plan=make_plan_with_pools(user, labels, cfg['routing'], pools)
        hits=retr.query(user, top_k=cfg['memory'].get('top_k',5))
        ctx='Relevant memory:\n'+'\n'.join([f"- {h['capsule'].get('input','')[:120]} :: {h['capsule'].get('output','')[:200]}" for h in hits]) if hits else ''
        concrete=[] 
        for w in plan:
            if w.role in pools:
                picked=rot.pick(w.role); concrete.append(WorkUnit(role=picked or w.role, goal=w.goal, inputs=w.inputs, parent=w.parent, priority=w.priority))
            else: concrete.append(w)
        t0=time.time(); outputs=mgr.run_plan(concrete, call_agent_low, context_block=ctx); latency=time.time()-t0
        for wu in concrete: rot.record_metrics(wu.role, latency_s=latency)
        critic_raw=outputs.get('C',''); ok=None; cj={}
        try:
            if critic_raw.strip().startswith('{'): cj=json.loads(critic_raw); ok=cj.get('ok',None)
        except: pass
        outputs, revised = mgr.bounded_revision(cj, outputs, call_agent_low, context_block=ctx)
        merged=merge_outputs(outputs.get('A','') or outputs.get('A1','') or outputs.get('A2',''), outputs.get('B','') or outputs.get('B1','') or outputs.get('B2',''), cfg.get('merge',{}).get('style','dialogic'))
        print('\n🤖 Spine:\n', merged)
        if critic_raw: print('\n[Critic C]:\n', critic_raw)
        if revised: print('\n[Manager]: Applied one bounded revision.')
        metrics.log('turn', {'latency_s': latency, 'labels': labels, 'agents_used': list(outputs.keys())})
if __name__=='__main__': main()
