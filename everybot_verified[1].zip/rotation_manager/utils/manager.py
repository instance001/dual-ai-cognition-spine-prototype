
import time, uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
class WorkUnit:
    def __init__(self, role, goal, inputs, parent=None, priority=0):
        self.wid=str(uuid.uuid4()); self.parent=parent; self.role=role; self.goal=goal
        self.inputs=inputs or {}; self.priority=priority; self.status='queued'; self.output=''; self.error=None
        self.started_at=None; self.ended_at=None
class Manager:
    def __init__(self, agents_cfg, max_workers=4, revision_limit=1):
        self.agents_cfg=agents_cfg; self.max_workers=max_workers; self.revision_limit=revision_limit; self.revisions=0
    def run_plan(self, pipeline, call_agent_fn, context_block=''):
        done={}; pipeline=sorted(pipeline,key=lambda w:w.priority, reverse=True); i=0
        while i<len(pipeline):
            pr=pipeline[i].priority; wave=[]
            while i<len(pipeline) and pipeline[i].priority==pr: wave.append(pipeline[i]); i+=1
            with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
                futs=[]
                for w in wave:
                    w.status='running'; w.started_at=time.time()
                    prompt=w.inputs.get('prompt','')
                    if context_block and w.role in ('A','C','R'): prompt=f"{context_block}\n\nTask:\n{prompt}"
                    futs.append(pool.submit(call_agent_fn, w.role, self.agents_cfg[w.role], prompt))
                for fut, w in zip(as_completed(futs), wave):
                    try: role,text=fut.result(); w.output=text; w.status='done'; w.ended_at=time.time(); done[role]=text
                    except Exception as e: w.status='failed'; w.error=str(e); w.ended_at=time.time(); done[w.role]=f"[error:{type(e).__name__}] {e}"
        return done
    def bounded_revision(self, critic_json, outputs, call_agent_fn, context_block=''):
        if not isinstance(critic_json, dict): return outputs, False
        if critic_json.get('ok', True): return outputs, False
        if self.revisions >= self.revision_limit: return outputs, False
        target = 'A'
        if any('option' in str(x).lower() or 'creative' in str(x).lower() for x in critic_json.get('required_changes',[])): target = 'B'
        fix=f"Revise based on critic feedback:\n{critic_json}\n\nOriginal:\n{outputs.get(target,'')}"
        role, text = call_agent_fn(target, self.agents_cfg[target], fix)
        outputs[target]=text; self.revisions+=1; return outputs, True
