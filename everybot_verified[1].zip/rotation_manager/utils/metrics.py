import json, time, os
class MetricsLogger:
    def __init__(self, path='memory/manager_metrics.jsonl'):
        self.path=path; os.makedirs(os.path.dirname(path), exist_ok=True)
    def log(self, t, data):
        with open(self.path,'a',encoding='utf-8') as f:
            f.write(json.dumps({'ts':time.time(),'type':t, **(data or {})}, ensure_ascii=False)+'\n')
