
import time
from collections import deque, defaultdict
class AgentState:
    def __init__(self, agent_id, cooldown_s=5, quota_per_min=12):
        self.id=agent_id; self.cooldown_s=cooldown_s; self.quota_per_min=quota_per_min
        self.last_used=0.0; self.in_cooldown_until=0.0; self.used_this_min=0; self.window_start=time.time()
        self.lat_hist=deque(maxlen=50); self.tokens_in_hist=deque(maxlen=50); self.tokens_out_hist=deque(maxlen=50)
        self.repeats_hist=deque(maxlen=50); self.timeouts=0; self.degrades=0
    def tick(self):
        if time.time() - self.window_start >= 60.0: self.window_start=time.time(); self.used_this_min=0
    def available(self):
        self.tick(); return (time.time()>=self.in_cooldown_until) and (self.used_this_min < self.quota_per_min)
    def record(self, latency_s=None): self.last_used=time.time(); self.used_this_min+=1
class Rotation:
    def __init__(self, pools_cfg, agents_cfg):
        self.pools=pools_cfg or {}; self.agents_cfg=agents_cfg or {}; self.rr={k:0 for k in self.pools.keys()}
        self.state={aid: AgentState(aid, agents_cfg.get(aid,{}).get('cooldown_s',5), agents_cfg.get(aid,{}).get('quota_per_min',12)) for aid in agents_cfg.keys()}
    def pick(self, pool_name):
        ids=self.pools.get(pool_name,[]); 
        if not ids: return None
        avail=[a for a in ids if self.state[a].available()] or ids
        idx=self.rr.get(pool_name,0)%len(avail); self.rr[pool_name]=idx+1
        return avail[idx]
    def record_metrics(self, agent_id, **kw): 
        if agent_id in self.state: self.state[agent_id].record(**kw)
