# Rotation Manager
Use `main_manager.py` or `main_manager_pool.py` with your top-level `config.json`.
