
import json, os
from datetime import datetime
from utils.manager import Manager, WorkUnit
from utils.merge import merge_outputs
from utils.router import classify
from utils.retriever import BM25Index
try:
    from utils.embed_retriever import EmbedIndex
except Exception:
    EmbedIndex=None
from agents.agent_a import query_agent_a
from agents.agent_b import query_agent_b
from agents.agent_c import query_agent_c
CONFIG_PATH='config.json'
def load_config(): return json.load(open(CONFIG_PATH,'r',encoding='utf-8'))
def now_iso(): 
    from datetime import datetime
    return datetime.now().isoformat(timespec='seconds')
def ensure_mem(p): os.makedirs(os.path.dirname(p), exist_ok=True); open(p,'a').close()
def save_cap(p,c): open(p,'a',encoding='utf-8').write(json.dumps(c, ensure_ascii=False)+'\n')
def call_agent(name,cfg,prompt):
    host=cfg['host']; model=cfg['model']; timeout_s=cfg.get('timeout_s',20); system=cfg.get('system','')
    if name=='A': return 'A', query_agent_a(host, model, prompt, system, timeout_s)
    if name=='B': return 'B', query_agent_b(host, model, prompt, system, timeout_s)
    if name=='C': return 'C', query_agent_c(host, model, prompt, system, timeout_s)
    if name in ('R','Ch','S','T'): return name, query_agent_a(host, model, prompt, system, timeout_s)
    return name, f'[error] unknown agent {name}'
def build_retr(cfg, path):
    r=cfg['memory'].get('retriever','bm25').lower()
    if r=='embed' and EmbedIndex is not None: idx=EmbedIndex(path, cfg['memory'].get('embed_model','all-MiniLM-L6-v2'))
    else: idx=BM25Index(path); r='bm25'
    idx.build(); return idx, r
def make_plan(prompt, labels, routing):
    prio={'A':3,'C':2,'R':2,'B':2,'S':1,'Ch':1,'T':2}; seq=[]
    for lb in labels:
        for a in routing.get(lb, []):
            if a.endswith('?'): a=a[:-1]
            if a not in seq: seq.append(a)
    return [WorkUnit(role=a, goal=f'{a} on task', inputs={'prompt':prompt}, priority=prio.get(a,1)) for a in seq]
def main():
    cfg=load_config(); mem=cfg['memory']['path']; ensure_mem(mem)
    retr,rtype=build_retr(cfg, mem)
    mgr=Manager(cfg['agents'], max_workers=cfg.get('manager',{}).get('max_workers',4), revision_limit=cfg.get('manager',{}).get('revision_limit',1))
    print(f'🕹️ Manager mode online (retriever={rtype.upper()}). Type exit to quit.')
    while True:
        user=input('\n🗣️ You: ').strip()
        if user.lower() in ('exit','quit'): break
        labels=classify(user); plan=make_plan(user, labels, cfg['routing'])
        hits=retr.query(user, top_k=cfg['memory'].get('top_k',5))
        ctx='Relevant memory:\n'+'\n'.join([f"- {h['capsule'].get('input','')[:120]} :: {h['capsule'].get('output','')[:200]}" for h in hits]) if hits else ''
        outputs=mgr.run_plan(plan, call_agent, context_block=ctx)
        critic_raw=outputs.get('C',''); ok=None; cj={}
        try:
            if critic_raw.strip().startswith('{'): cj=json.loads(critic_raw); ok=cj.get('ok',None)
        except: pass
        outputs, revised = mgr.bounded_revision(cj, outputs, call_agent, context_block=ctx)
        merged=merge_outputs(outputs.get('A',''), outputs.get('B',''), cfg.get('merge',{}).get('style','dialogic'))
        print('\n🤖 Spine:\n', merged)
        if critic_raw: print('\n[Critic C]:\n', critic_raw)
        if revised: print('\n[Manager]: Applied one bounded revision.')
        cap={'timestamp':now_iso(), 'input':user, 'output':merged, 'agents':outputs, 'tags':labels, 'critic_ok':ok, 'state':'stored', 'manager': {'revisions_used': mgr.revisions}}
        save_cap(mem, cap); retr.add_capsule(cap)
if __name__=='__main__': main()
