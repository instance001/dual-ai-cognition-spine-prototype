# University Examples
Dual AI sessions for labs and classes.
