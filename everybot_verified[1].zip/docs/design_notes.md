# Design Notes
Multi-agent cognition spine, rotation pools, memory retrievers.
