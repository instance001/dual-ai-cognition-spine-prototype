# Philosophy
Symbound ethics and Everybot design.
