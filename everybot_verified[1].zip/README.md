# 🌍 Everybot — Open Symbound AI Framework
Includes working code for chatty/, rotation_manager/, helix_session/, plus ethics/ and docs/.
